import React, { useState } from 'react';
import './App.css';

import './assets/scss/theme.scss';
import Select from 'react-select';
import {
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Form,
  FormGroup,
  Label,
  Input,
} from 'reactstrap';
import classnames from 'classnames';
import Process from './components/Process';
import SourceManagement from './components/SourceConfig';
import MappingManagement from './components/Mapping';
import RuleComponent from './components/Rules';
import ErrorRuleComponent from './components/GlobalRules';

interface Process {
  id: string;
  sourceId: string;
  sourceName: string;
  targetTable: string;
  LoadRules: string;
  activityFlag: string;
  order: number;
  lastUpdatedTime: string;
}

const sourceOptions = [
  { value: 'SRC001', label: 'Source A' },
  { value: 'SRC002', label: 'Source B' },
];

const activityOptions = [
  { value: 'Active', label: 'Active' },
  { value: 'Inactive', label: 'Inactive' },
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('1');
  const [modal, setModal] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [formState, setFormState] = useState<Process>({
    id: '',
    sourceId: '',
    sourceName: '',
    targetTable: '',
    LoadRules: '',
    activityFlag: '',
    order: 0,
    lastUpdatedTime: '',
  });

  const [data, setData] = useState<Process[]>([
    {
      id: '1',
      sourceId: 'SRC001',
      sourceName: 'Source A',
      targetTable: 'TargetTable1',
      LoadRules: 'Rule1',
      activityFlag: 'Active',
      order: 1,
      lastUpdatedTime: '2024-10-07 10:00:00',
    },
    {
      id: '2',
      sourceId: 'SRC002',
      sourceName: 'Source B',
      targetTable: 'TargetTable2',
      LoadRules: 'Rule2',
      activityFlag: 'Inactive',
      order: 2,
      lastUpdatedTime: '2024-10-07 11:00:00',
    },
  ]);

  const toggleModal = () => setModal(!modal);

  const toggle = (tab: string) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormState({ ...formState, [name]: value });
  };

  const handleAddProcess = () => {
    const newProcess: Process = {
      ...formState,
      id: (data.length + 1).toString(),
      lastUpdatedTime: new Date().toISOString().split('T')[0],
    };
    setData([...data, newProcess]);
    toggleModal();
    resetForm();
  };

  const handleEditProcess = () => {
    const updatedData = data.map((item) =>
      item.id === formState.id
        ? {
            ...formState,
            lastUpdatedTime: new Date().toISOString().split('T')[0], // Update lastUpdatedTime
          }
        : item,
    );
    setData(updatedData);
    toggleModal();
    resetForm();
  };

  const resetForm = () => {
    setFormState({
      id: '',
      sourceId: '',
      sourceName: '',
      targetTable: '',
      LoadRules: '',
      activityFlag: '',
      order: 0,
      lastUpdatedTime: '',
    });
    setIsEditing(false);
  };

  return (
    <React.Fragment>
      <h2>ETL CONFIG RULES</h2>
      <Nav pills tabs className="m-3">
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === '1' })}
            onClick={() => toggle('1')}
          >
            Process
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === '2' })}
            onClick={() => toggle('2')}
          >
            Source Config
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === '3' })}
            onClick={() => toggle('3')}
          >
            Mapping Field
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === '4' })}
            onClick={() => toggle('4')}
          >
            ETL Rules
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === '5' })}
            onClick={() => toggle('5')}
          >
            Global Rules
          </NavLink>
        </NavItem>
      </Nav>

      <TabContent activeTab={activeTab}>
        <TabPane tabId="1">
          <Process />
        </TabPane>
        <TabPane tabId="2">
          <SourceManagement />
        </TabPane>
        <TabPane tabId="3">
          <MappingManagement />
        </TabPane>
        <TabPane tabId="4">
          <RuleComponent />
        </TabPane>
        <TabPane tabId="5">
          <ErrorRuleComponent />
        </TabPane>
      </TabContent>

      <Modal isOpen={modal} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>
          {isEditing ? 'Edit Process' : 'Add Process'}
        </ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
              <Label for="sourceId">Source ID</Label>
              <Select
                name="sourceId"
                options={sourceOptions}
                value={sourceOptions.find(
                  (option) => option.value === formState.sourceId,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    sourceId: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for="sourceName">Source Name</Label>
              <Input
                type="text"
                name="sourceName"
                id="sourceName"
                value={formState.sourceName}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="targetTable">Target Table</Label>
              <Input
                type="text"
                name="targetTable"
                id="targetTable"
                value={formState.targetTable}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="LoadRules">Load Rules</Label>
              <Input
                type="text"
                name="LoadRules"
                id="LoadRules"
                value={formState.LoadRules}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="activityFlag">Activity Flag</Label>
              <Select
                name="activityFlag"
                options={activityOptions}
                value={activityOptions.find(
                  (option) => option.value === formState.activityFlag,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    activityFlag: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for="order">Order</Label>
              <Input
                type="number"
                name="order"
                id="order"
                value={formState.order}
                onChange={(e) =>
                  setFormState({
                    ...formState,
                    order: parseInt(e.target.value),
                  })
                }
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button
            color="primary"
            onClick={isEditing ? handleEditProcess : handleAddProcess}
          >
            {isEditing ? 'Update Process' : 'Add Process'}
          </Button>
          <Button color="secondary" onClick={toggleModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </React.Fragment>
  );
};

export default App;
