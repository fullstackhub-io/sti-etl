import React from 'react';

export function View({ onClick, icon = 'mdi mdi-eye' }) {
  return (
    <button
      style={{ ...styles.container }}
      onClick={onClick}
      aria-label="Delete"
      className="btn-primary btn-sm"
    >
      <i className={icon} style={{ ...styles.icon }} aria-hidden="true"></i>
    </button>
  );
}

const styles = {
  container: {
    marginLeft: '5px',
    marginRight: '5px',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#556ee6',
    color: 'white',
    padding: '3px',
    paddingLeft: '8px',
    paddingRight: '8px',
    border: 'none',
    borderRadius: '5px',
  },
  icon: {
    color: 'white',
  },
};
