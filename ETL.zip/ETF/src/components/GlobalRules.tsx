import React, { useMemo, useState } from 'react';
import TableContainer from './table';
import Select from 'react-select';
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Form,
  FormGroup,
  Label,
  Input,
} from 'reactstrap';

interface ErrorRule {
  id: string;
  errorId: string;
  validationLogic: string;
  parameter: string;
  errorMessage: string;
  createdAt: string;
  activeFlag: string;
}

export default function ErrorRuleComponent() {
  const activeFlagOptions = [
    { value: 'Active', label: 'Active' },
    { value: 'Inactive', label: 'Inactive' },
  ];

  const [modal, setModal] = useState<boolean>(false);
  const [deleteModal, setDeleteModal] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [formState, setFormState] = useState<ErrorRule>({
    id: '',
    errorId: '',
    validationLogic: '',
    parameter: '',
    errorMessage: '',
    createdAt: '',
    activeFlag: '',
  });

  const [data, setData] = useState<ErrorRule[]>([
    {
      id: '1',
      errorId: 'E001',
      validationLogic: 'Logic 1',
      parameter: 'Param 1',
      errorMessage: 'Error in Validation 1',
      createdAt: '2024-10-07 10:00:00',
      activeFlag: 'Active',
    },
    // Add more initial error rules as needed
  ]);

  const toggleModal = () => setModal(!modal);
  const toggleDeleteModal = () => setDeleteModal(!deleteModal);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormState({ ...formState, [name]: value });
  };

  const handleAddErrorRule = () => {
    const newErrorRule: ErrorRule = {
      ...formState,
      id: (data.length + 1).toString(),
      createdAt: new Date().toISOString().split('T')[0],
    };
    setData([...data, newErrorRule]);
    toggleModal();
    resetForm();
  };

  const handleEditErrorRule = () => {
    const updatedData = data.map((item) =>
      item.id === formState.id
        ? { ...formState, createdAt: new Date().toISOString().split('T')[0] }
        : item,
    );
    setData(updatedData);
    toggleModal();
    resetForm();
  };

  const handleEditClick = (errorRule: ErrorRule) => {
    setFormState(errorRule);
    setIsEditing(true);
    toggleModal();
  };

  const handleDeleteClick = (errorRule: ErrorRule) => {
    setFormState(errorRule);
    toggleDeleteModal();
  };

  const confirmDelete = () => {
    const updatedData = data.filter((item) => item.id !== formState.id);
    setData(updatedData);
    toggleDeleteModal();
    resetForm();
  };

  const resetForm = () => {
    setFormState({
      id: '',
      errorId: '',
      validationLogic: '',
      parameter: '',
      errorMessage: '',
      createdAt: '',
      activeFlag: '',
    });
    setIsEditing(false);
  };

  const columns = useMemo(
    () => [
      { header: 'Rule Id', accessorKey: 'id' },
      { header: 'Error Id', accessorKey: 'errorId' },
      { header: 'Validation Logic', accessorKey: 'validationLogic' },
      { header: 'Parameter', accessorKey: 'parameter' },
      { header: 'Error Message', accessorKey: 'errorMessage' },
      { header: 'Created At', accessorKey: 'createdAt' },
      { header: 'Active Flag', accessorKey: 'activeFlag' },
    ],
    [],
  );

  return (
    <React.Fragment>
      <TableContainer
        columns={columns}
        data={data}
        isGlobalFilter={false}
        buttonName="Add Error Rule"
        buttonClass="btn-primary"
        SearchPlaceholder="Enter Text to search"
        isAddButton={true}
        handleUserClick={toggleModal}
        moveTONextOnEdit={handleEditClick}
        moveTONextPage={true}
        onDelete={handleDeleteClick} // Add this prop for delete functionality
      />

      {/* Add/Edit Modal */}
      <Modal isOpen={modal} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>
          {isEditing ? 'Edit Error Rule' : 'Add Error Rule'}
        </ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
              <Label for="errorId">Error Id</Label>
              <Input
                type="text"
                name="errorId"
                id="errorId"
                value={formState.errorId}
                onChange={handleInputChange}
                readOnly={isEditing} // Set readOnly for edit mode
              />
            </FormGroup>
            <FormGroup>
              <Label for="validationLogic">Validation Logic</Label>
              <Input
                type="text"
                name="validationLogic"
                id="validationLogic"
                value={formState.validationLogic}
                onChange={handleInputChange}
                readOnly={isEditing} // Set readOnly for edit mode
              />
            </FormGroup>
            <FormGroup>
              <Label for="parameter">Parameter</Label>
              <Input
                type="text"
                name="parameter"
                id="parameter"
                value={formState.parameter}
                onChange={handleInputChange}
                readOnly={isEditing} // Set readOnly for edit mode
              />
            </FormGroup>
            <FormGroup>
              <Label for="errorMessage">Error Message</Label>
              <Input
                type="text"
                name="errorMessage"
                id="errorMessage"
                value={formState.errorMessage}
                onChange={handleInputChange}
                readOnly={isEditing} // Set readOnly for edit mode
              />
            </FormGroup>
            <FormGroup>
              <Label for="createdAt">Created At</Label>
              <Input
                type="text"
                name="createdAt"
                id="createdAt"
                value={formState.createdAt}
                onChange={handleInputChange}
                disabled // Disable input for createdAt
              />
            </FormGroup>
            <FormGroup>
              <Label for="activeFlag">Active Flag</Label>
              <Select
                name="activeFlag"
                options={activeFlagOptions}
                value={activeFlagOptions.find(
                  (option) => option.value === formState.activeFlag,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    activeFlag: selectedOption?.value || '',
                  })
                }
                isDisabled={isEditing} // Disable select for edit mode
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button
            color="primary"
            onClick={isEditing ? handleEditErrorRule : handleAddErrorRule}
          >
            {isEditing ? 'Update Error Rule' : 'Add Error Rule'}
          </Button>
          <Button color="secondary" onClick={toggleModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={deleteModal} toggle={toggleDeleteModal}>
        <ModalHeader toggle={toggleDeleteModal}>Delete Error Rule</ModalHeader>
        <ModalBody>
          <p>Are you sure you want to delete the following error rule?</p>
          <Form>
            <FormGroup>
              <Label for="errorId">Error Id</Label>
              <Input
                type="text"
                name="errorId"
                id="errorId"
                value={formState.errorId}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="validationLogic">Validation Logic</Label>
              <Input
                type="text"
                name="validationLogic"
                id="validationLogic"
                value={formState.validationLogic}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="parameter">Parameter</Label>
              <Input
                type="text"
                name="parameter"
                id="parameter"
                value={formState.parameter}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="errorMessage">Error Message</Label>
              <Input
                type="text"
                name="errorMessage"
                id="errorMessage"
                value={formState.errorMessage}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="createdAt">Created At</Label>
              <Input
                type="text"
                name="createdAt"
                id="createdAt"
                value={formState.createdAt}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="activeFlag">Active Flag</Label>
              <Input
                type="text"
                name="activeFlag"
                id="activeFlag"
                value={formState.activeFlag}
                readOnly
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="danger" onClick={confirmDelete}>
            Delete Rule
          </Button>
          <Button color="secondary" onClick={toggleDeleteModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </React.Fragment>
  );
}
