import React, { useMemo, useState } from 'react';
import TableContainer from './table';
import Select from 'react-select';
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Form,
  FormGroup,
  Label,
  Input,
} from 'reactstrap';

interface Rule {
  id: string;
  ruleName: string;
  ruleType: string;
  parameter: string;
  isSql: boolean;
  errorMessage: string;
  createdAt: string;
  activeFlag: string;
}

export default function RuleComponent() {
  const ruleTypeOptions = [
    { value: 'Validation', label: 'Validation' },
    { value: 'Transformation', label: 'Transformation' },
  ];

  const activeFlagOptions = [
    { value: 'Active', label: 'Active' },
    { value: 'Inactive', label: 'Inactive' },
  ];

  const [modal, setModal] = useState<boolean>(false);
  const [deleteModal, setDeleteModal] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [formState, setFormState] = useState<Rule>({
    id: '',
    ruleName: '',
    ruleType: '',
    parameter: '',
    isSql: false,
    errorMessage: '',
    createdAt: '',
    activeFlag: '',
  });

  const [data, setData] = useState<Rule[]>([
    {
      id: '1',
      ruleName: 'Rule 1',
      ruleType: 'Validation',
      parameter: 'Param 1',
      isSql: true,
      errorMessage: 'Error in Rule 1',
      createdAt: '2024-10-07 10:00:00',
      activeFlag: 'Active',
    },
    // Add more initial rules as needed
  ]);

  const toggleModal = () => setModal(!modal);
  const toggleDeleteModal = () => setDeleteModal(!deleteModal);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormState({ ...formState, [name]: value });
  };

  const handleAddRule = () => {
    const newRule: Rule = {
      ...formState,
      id: (data.length + 1).toString(),
      createdAt: new Date().toISOString().split('T')[0],
    };
    setData([...data, newRule]);
    toggleModal();
    resetForm();
  };

  const handleEditRule = () => {
    const updatedData = data.map((item) =>
      item.id === formState.id
        ? { ...formState, createdAt: new Date().toISOString().split('T')[0] }
        : item,
    );
    setData(updatedData);
    toggleModal();
    resetForm();
  };

  const handleEditClick = (rule: Rule) => {
    setFormState(rule);
    setIsEditing(true);
    toggleModal();
  };

  const handleDeleteClick = (rule: Rule) => {
    console.log(rule, 'Rule is');
    setFormState(rule);
    toggleDeleteModal();
  };

  const confirmDelete = () => {
    const updatedData = data.filter((item) => item.id !== formState.id);
    setData(updatedData);
    toggleDeleteModal();
    resetForm();
  };

  const resetForm = () => {
    setFormState({
      id: '',
      ruleName: '',
      ruleType: '',
      parameter: '',
      isSql: false,
      errorMessage: '',
      createdAt: '',
      activeFlag: '',
    });
    setIsEditing(false);
  };

  const columns = useMemo(
    () => [
      { header: 'Rule Id', accessorKey: 'id' },
      { header: 'Rule Name', accessorKey: 'ruleName' },
      { header: 'Rule Type', accessorKey: 'ruleType' },
      { header: 'Parameter', accessorKey: 'parameter' },
      { header: 'Is SQL', accessorKey: 'isSql' },
      { header: 'Error Message', accessorKey: 'errorMessage' },
      { header: 'Created At', accessorKey: 'createdAt' },
      { header: 'Active Flag', accessorKey: 'activeFlag' },
    ],
    [],
  );

  return (
    <React.Fragment>
      <TableContainer
        columns={columns}
        data={data}
        isGlobalFilter={false}
        buttonName="Add Rule"
        buttonClass="primary"
        SearchPlaceholder="Enter Text to search"
        isAddButton={true}
        handleUserClick={toggleModal}
        moveTONextOnEdit={handleEditClick}
        moveTONextPage={true}
        onDelete={handleDeleteClick} // Add this prop for delete functionality
      />

      {/* Add/Edit Modal */}
      <Modal isOpen={modal} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>
          {isEditing ? 'Edit Rule' : 'Add Rule'}
        </ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
              <Label for="ruleName">Rule Name</Label>
              <Input
                type="text"
                name="ruleName"
                id="ruleName"
                value={formState.ruleName}
                onChange={handleInputChange}
                readOnly={isEditing} // Set readOnly for edit mode
              />
            </FormGroup>
            <FormGroup>
              <Label for="ruleType">Rule Type</Label>
              <Select
                name="ruleType"
                options={ruleTypeOptions}
                value={ruleTypeOptions.find(
                  (option) => option.value === formState.ruleType,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    ruleType: selectedOption?.value || '',
                  })
                }
                isDisabled={isEditing} // Disable select for edit mode
              />
            </FormGroup>
            <FormGroup>
              <Label for="parameter">Parameter</Label>
              <Input
                type="text"
                name="parameter"
                id="parameter"
                value={formState.parameter}
                onChange={handleInputChange}
                readOnly={isEditing} // Set readOnly for edit mode
              />
            </FormGroup>
            <FormGroup>
              <Label for="isSql">Is SQL</Label>
              <Select
                name="isSql"
                options={[
                  { value: true, label: 'Yes' },
                  { value: false, label: 'No' },
                ]}
                value={
                  formState.isSql
                    ? { value: true, label: 'Yes' }
                    : { value: false, label: 'No' }
                }
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    isSql: selectedOption?.value || false,
                  })
                }
                isDisabled={isEditing} // Disable select for edit mode
              />
            </FormGroup>
            <FormGroup>
              <Label for="errorMessage">Error Message</Label>
              <Input
                type="text"
                name="errorMessage"
                id="errorMessage"
                value={formState.errorMessage}
                onChange={handleInputChange}
                readOnly={isEditing} // Set readOnly for edit mode
              />
            </FormGroup>
            <FormGroup>
              <Label for="createdAt">Created At</Label>
              <Input
                type="text"
                name="createdAt"
                id="createdAt"
                value={formState.createdAt}
                onChange={handleInputChange}
                disabled // Disable input for createdAt
              />
            </FormGroup>
            <FormGroup>
              <Label for="activeFlag">Active Flag</Label>
              <Select
                name="activeFlag"
                options={activeFlagOptions}
                value={activeFlagOptions.find(
                  (option) => option.value === formState.activeFlag,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    activeFlag: selectedOption?.value || '',
                  })
                }
                isDisabled={isEditing} // Disable select for edit mode
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button
            color="primary"
            onClick={isEditing ? handleEditRule : handleAddRule}
          >
            {isEditing ? 'Update Rule' : 'Add Rule'}
          </Button>
          <Button color="secondary" onClick={toggleModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={deleteModal} toggle={toggleDeleteModal}>
        <ModalHeader toggle={toggleDeleteModal}>Delete Rule</ModalHeader>
        <ModalBody>
          <p>Are you sure you want to delete the following rule?</p>
          <Form>
            <FormGroup>
              <Label for="ruleName">Rule Name</Label>
              <Input
                type="text"
                name="ruleName"
                id="ruleName"
                value={formState.ruleName}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="ruleType">Rule Type</Label>
              <Input
                type="text"
                name="ruleType"
                id="ruleType"
                value={formState.ruleType}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="parameter">Parameter</Label>
              <Input
                type="text"
                name="parameter"
                id="parameter"
                value={formState.parameter}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="isSql">Is SQL</Label>
              <Input
                type="text"
                name="isSql"
                id="isSql"
                value={formState.isSql ? 'Yes' : 'No'}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="errorMessage">Error Message</Label>
              <Input
                type="text"
                name="errorMessage"
                id="errorMessage"
                value={formState.errorMessage}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="createdAt">Created At</Label>
              <Input
                type="text"
                name="createdAt"
                id="createdAt"
                value={formState.createdAt}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="activeFlag">Active Flag</Label>
              <Input
                type="text"
                name="activeFlag"
                id="activeFlag"
                value={formState.activeFlag}
                readOnly
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="danger" onClick={confirmDelete}>
            Delete Rule
          </Button>
          <Button color="secondary" onClick={toggleDeleteModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </React.Fragment>
  );
}
