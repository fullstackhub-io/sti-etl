import React, { useMemo, useState } from 'react';
import TableContainer from './table';
import Select from 'react-select';
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Form,
  FormGroup,
  Label,
  Input,
} from 'reactstrap';

interface MappingData {
  id: string;
  processId: string;
  sourceField: string;
  targetField: string;
  isMandatory: string;
  isDerived: string;
  validationRule: string;
  deidentificationRule: string;
  errorCheck: string;
  errorAction: string;
  defaultValue: string;
}

export default function MappingManagement() {
  const mappingOptions = [
    { value: 'Map001', label: 'Mapping 1' },
    { value: 'Map002', label: 'Mapping 2' },
  ];

  const processOptions = [
    { value: 'Proc001', label: 'Process 1' },
    { value: 'Proc002', label: 'Process 2' },
  ];

  const isMandatoryOptions = [
    { value: 'Yes', label: 'Yes' },
    { value: 'No', label: 'No' },
  ];

  const isDerivedOptions = [
    { value: 'Yes', label: 'Yes' },
    { value: 'No', label: 'No' },
  ];

  const deidentificationOptions = [
    { value: 'None', label: 'None' },
    { value: 'Hashing', label: 'Hashing' },
    { value: 'Masking', label: 'Masking' },
  ];

  const [modal, setModal] = useState<boolean>(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [formState, setFormState] = useState<MappingData>({
    id: '',
    processId: '',
    sourceField: '',
    targetField: '',
    isMandatory: '',
    isDerived: '',
    validationRule: '',
    deidentificationRule: '',
    errorCheck: '',
    errorAction: '',
    defaultValue: '',
  });

  const [data, setData] = useState<MappingData[]>([
    {
      id: '1',
      processId: 'Proc001',
      sourceField: 'SourceField1',
      targetField: 'TargetField1',
      isMandatory: 'Yes',
      isDerived: 'No',
      validationRule: 'Rule1',
      deidentificationRule: 'None',
      errorCheck: 'Check1',
      errorAction: 'Action1',
      defaultValue: 'Default1',
    },
    {
      id: '2',
      processId: 'Proc002',
      sourceField: 'SourceField2',
      targetField: 'TargetField2',
      isMandatory: 'No',
      isDerived: 'Yes',
      validationRule: 'Rule2',
      deidentificationRule: 'Masking',
      errorCheck: 'Check2',
      errorAction: 'Action2',
      defaultValue: 'Default2',
    },
  ]);

  const toggleModal = () => setModal(!modal);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormState({ ...formState, [name]: value });
  };

  const handleAddMapping = () => {
    const newMapping: MappingData = {
      ...formState,
      id: (data.length + 1).toString(),
    };
    setData([...data, newMapping]);
    toggleModal();
    resetForm();
  };
  const toggleDeleteModal = () => setDeleteModal(!deleteModal);

  const handleEditMapping = () => {
    const updatedData = data.map((item) =>
      item.id === formState.id ? { ...formState } : item,
    );
    setData(updatedData);
    toggleModal();
    resetForm();
  };

  const handleEditClick = (mapping: MappingData) => {
    setFormState(mapping);
    setIsEditing(true);
    toggleModal();
  };
  const handleDeleteClick = (mapping: MappingData) => {
    setFormState(mapping);
    toggleDeleteModal();
  };

  const resetForm = () => {
    setFormState({
      id: '',
      processId: '',
      sourceField: '',
      targetField: '',
      isMandatory: '',
      isDerived: '',
      validationRule: '',
      deidentificationRule: '',
      errorCheck: '',
      errorAction: '',
      defaultValue: '',
    });
    setIsEditing(false);
  };

  const columns = useMemo(
    () => [
      { header: 'Mapping Id', accessorKey: 'id' },
      { header: 'Process ID', accessorKey: 'processId' },
      { header: 'Source Field', accessorKey: 'sourceField' },
      { header: 'Target Field', accessorKey: 'targetField' },
      { header: 'IS Mandatory', accessorKey: 'isMandatory' },
      { header: 'Is Derived', accessorKey: 'isDerived' },
      { header: 'Validation Rule', accessorKey: 'validationRule' },
      { header: 'Deidentification Rule', accessorKey: 'deidentificationRule' },
      { header: 'Error Check', accessorKey: 'errorCheck' },
      { header: 'Error Action', accessorKey: 'errorAction' },
      { header: 'Default Value', accessorKey: 'defaultValue' },
    ],
    [],
  );
  const handleDeleteSource = () => {
    const updatedData = data.filter((item) => item.id !== formState.id);
    setData(updatedData);
    toggleDeleteModal();
    resetForm();
  };
  return (
    <React.Fragment>
      <TableContainer
        columns={columns}
        data={data}
        isGlobalFilter={false}
        buttonName="Add Mapping"
        buttonClass="primary"
        SearchPlaceholder="Enter text to search"
        isAddButton={true}
        handleUserClick={toggleModal}
        moveTONextOnEdit={handleEditClick}
        moveTONextPage={true}
        onDelete={handleDeleteClick}
      />

      <Modal isOpen={modal} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>
          {isEditing ? 'Edit Mapping' : 'Add Mapping'}
        </ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
              <Label for="id">Mapping ID</Label>
              <Select
                name="id"
                options={mappingOptions}
                value={mappingOptions.find(
                  (option) => option.value === formState.id,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    id: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for="processId">Process ID</Label>
              <Select
                name="processId"
                options={processOptions}
                value={processOptions.find(
                  (option) => option.value === formState.processId,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    processId: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for="sourceField">Source Field</Label>
              <Input
                type="text"
                name="sourceField"
                id="sourceField"
                value={formState.sourceField}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="targetField">Target Field</Label>
              <Input
                type="text"
                name="targetField"
                id="targetField"
                value={formState.targetField}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="isMandatory">IS Mandatory</Label>
              <Select
                name="isMandatory"
                options={isMandatoryOptions}
                value={isMandatoryOptions.find(
                  (option) => option.value === formState.isMandatory,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    isMandatory: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for="isDerived">Is Derived</Label>
              <Select
                name="isDerived"
                options={isDerivedOptions}
                value={isDerivedOptions.find(
                  (option) => option.value === formState.isDerived,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    isDerived: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for="validationRule">Validation Rule</Label>
              <Input
                type="text"
                name="validationRule"
                id="validationRule"
                value={formState.validationRule}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="deidentificationRule">Deidentification Rule</Label>
              <Select
                name="deidentificationRule"
                options={deidentificationOptions}
                value={deidentificationOptions.find(
                  (option) => option.value === formState.deidentificationRule,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    deidentificationRule: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for="errorCheck">Error Check</Label>
              <Input
                type="text"
                name="errorCheck"
                id="errorCheck"
                value={formState.errorCheck}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="errorAction">Error Action</Label>
              <Input
                type="text"
                name="errorAction"
                id="errorAction"
                value={formState.errorAction}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="defaultValue">Default Value</Label>
              <Input
                type="text"
                name="defaultValue"
                id="defaultValue"
                value={formState.defaultValue}
                onChange={handleInputChange}
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button
            color="primary"
            onClick={isEditing ? handleEditMapping : handleAddMapping}
          >
            {isEditing ? 'Update Mapping' : 'Add Mapping'}
          </Button>
          <Button color="secondary" onClick={toggleModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
      <Modal isOpen={deleteModal} toggle={toggleDeleteModal}>
        <ModalHeader toggle={toggleDeleteModal}>{'Delete Mapping'}</ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
              <Label for="id">Mapping ID</Label>
              <Select
                name="id"
                options={mappingOptions}
                value={mappingOptions.find(
                  (option) => option.value === formState.id,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    id: selectedOption?.value || '',
                  })
                }
                isDisabled={true}
              />
            </FormGroup>
            <FormGroup>
              <Label for="processId">Process ID</Label>
              <Select
                name="processId"
                options={processOptions}
                value={processOptions.find(
                  (option) => option.value === formState.processId,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    processId: selectedOption?.value || '',
                  })
                }
                isDisabled={true}
              />
            </FormGroup>
            <FormGroup>
              <Label for="sourceField">Source Field</Label>
              <Input
                type="text"
                name="sourceField"
                id="sourceField"
                value={formState.sourceField}
                onChange={handleInputChange}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="targetField">Target Field</Label>
              <Input
                type="text"
                name="targetField"
                id="targetField"
                value={formState.targetField}
                onChange={handleInputChange}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="isMandatory">IS Mandatory</Label>
              <Select
                name="isMandatory"
                options={isMandatoryOptions}
                value={isMandatoryOptions.find(
                  (option) => option.value === formState.isMandatory,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    isMandatory: selectedOption?.value || '',
                  })
                }
                isDisabled={true}
              />
            </FormGroup>
            <FormGroup>
              <Label for="isDerived">Is Derived</Label>
              <Select
                name="isDerived"
                options={isDerivedOptions}
                value={isDerivedOptions.find(
                  (option) => option.value === formState.isDerived,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    isDerived: selectedOption?.value || '',
                  })
                }
                isDisabled={true}
              />
            </FormGroup>
            <FormGroup>
              <Label for="validationRule">Validation Rule</Label>
              <Input
                type="text"
                name="validationRule"
                id="validationRule"
                value={formState.validationRule}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="deidentificationRule">Deidentification Rule</Label>
              <Select
                name="deidentificationRule"
                options={deidentificationOptions}
                value={deidentificationOptions.find(
                  (option) => option.value === formState.deidentificationRule,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    deidentificationRule: selectedOption?.value || '',
                  })
                }
                isDisabled={true}
              />
            </FormGroup>
            <FormGroup>
              <Label for="errorCheck">Error Check</Label>
              <Input
                type="text"
                name="errorCheck"
                id="errorCheck"
                value={formState.errorCheck}
                readOnly
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="errorAction">Error Action</Label>
              <Input
                type="text"
                name="errorAction"
                id="errorAction"
                value={formState.errorAction}
                readOnly
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="defaultValue">Default Value</Label>
              <Input
                type="text"
                name="defaultValue"
                id="defaultValue"
                value={formState.defaultValue}
                onChange={handleInputChange}
                readOnly
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="danger" onClick={handleDeleteSource}>
            Delete
          </Button>
          <Button color="secondary" onClick={toggleDeleteModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </React.Fragment>
  );
}
