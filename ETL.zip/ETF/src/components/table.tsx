/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { Fragment, useEffect, useMemo, useRef, useState } from 'react';
import { Row, Table, Button, Col } from 'reactstrap';
import { Link } from 'react-router-dom';

import {
  useReactTable,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  flexRender,
  ColumnDef,
  RowData,
} from '@tanstack/react-table';

import { rankItem } from '@tanstack/match-sorter-utils';

import { Edit } from './Edit';
import { Delete } from './Delete';
import { View } from './View';
import { Save } from './Save';
import Select from 'react-select';
type FilterComponentProps = {
  column: any; // Adjust based on your column structure
};

type CustomFilterComponent = React.FC<FilterComponentProps>;

// Define a type that combines ColumnDef with additional properties
type CustomColumnDef<T> = ColumnDef<T> & {
  filterComponent?: CustomFilterComponent;
  editComponent?: (props: {
    value: any;
    onChange: (value: any) => void;
  }) => JSX.Element;
};
type CustomColumnDefs<TData extends RowData, TValue = unknown> = ColumnDef<
  TData,
  TValue
> & {
  editComponent?: React.ComponentType<{
    value: any;
    onChange: (newValue: any) => void;
  }>;
};
const Filter = ({ column }) => {
  const columnFilterValue = column.getFilterValue();

  return (
    <DebouncedInput
      type="text"
      value={columnFilterValue ?? ''}
      onChange={(value) => column.setFilterValue(value)}
      placeholder="Search"
      className="border shadow rounded"
      list={column.id + 'list'}
    />
  );
};

const DebouncedInput = ({
  value: initialValue,
  onChange,
  debounce = 500,
  ...props
}) => {
  const [value, setValue] = useState(initialValue);

  useEffect(() => {
    setValue(initialValue);
  }, [initialValue]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      onChange(value);
    }, debounce);

    return () => clearTimeout(timeout);
  }, [debounce, onChange, value]);

  return (
    <React.Fragment>
      <Col>
        <input
          {...props}
          className="form-control"
          value={value}
          onChange={(e) => setValue(e.target.value)}
        />
      </Col>
    </React.Fragment>
  );
};

export function TableContainer({
  columns = [],
  data = [],
  tableClass = '',
  theadClass = '',
  divClassName = '',
  isBordered = false,
  isPagination = false,
  isGlobalFilter = false,
  paginationWrapper = '',
  SearchPlaceholder = '',
  pagination = '',
  buttonClass = '',
  buttonName = '',
  isAddButton = false,
  isCustomPageSize = false,
  handleUserClick = () => {},
  isJobListGlobalFilter = false,
  showActionColumn = true,
  onEdit = (item) => {},
  onDelete = (id: any) => {},
  columnDefs = [],
  onCellEdit = (id: any, cell_id: any, newValue?: any) => {},
  selectedVlaue = { label: '', value: undefined },
  CustomIcon = null,
  customIconOnClick = (id: string) => {},
  moveTONextOnEdit = (row) => {},
  moveTONextPage = false,
}) {
  const [columnFilters, setColumnFilters] = useState([]);
  const [globalFilter, setGlobalFilter] = useState('');
  const [tableData, setTableData] = useState(data);
  const fuzzyFilter = (row, columnId, value, addMeta) => {
    const itemRank = rankItem(row.getValue(columnId), value);
    addMeta({
      itemRank,
    });
    return itemRank.passed;
  };
  useEffect(() => {
    setTableData(data);
  }, [data]);
  const dropdownFilterFn = (row, columnId, value) => {
    const rowValue = row.getValue(columnId);
    return value === '' || rowValue === value;
  };

  const table = useReactTable({
    columns,
    data,
    filterFns: {
      fuzzy: fuzzyFilter,
      dropdown: dropdownFilterFn,
    },
    state: {
      columnFilters,
      globalFilter,
    },
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    globalFilterFn: fuzzyFilter,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });

  const {
    getHeaderGroups,
    getRowModel,
    getCanPreviousPage,
    getCanNextPage,
    getPageOptions,
    setPageIndex,
    nextPage,
    previousPage,
    getState,
  } = table;
  const [editable, setEditable] = useState(null);

  const headerGroups = getHeaderGroups();
  const allColumns = headerGroups.flatMap((headerGroup) => headerGroup.headers);
  const showSelect = allColumns.length > 13;
  const [initialVisibleColumn, setInitialVisibleColumn] = useState(() => {
    return allColumns.length > 13
      ? allColumns.slice(0, 13).map((column) => column.id)
      : allColumns.map((column) => column.id);
  });
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [tempRowData, setTempRowData] = useState({});
  const selectRef = useRef(null);

  const remainingColumns = allColumns.filter(
    (column) => !initialVisibleColumn.includes(column.id),
  );

  const options = remainingColumns.map((column) => ({
    value: column.id,
    label: column.id,
  }));
  const customStyles = {
    menu: (provided) => ({
      ...provided,
      zIndex: 9999,
    }),
    control: (provided) => ({
      ...provided,
      margin: '0 auto',
    }),
  };

  const handleChange = (selectedOptions) => {
    const selectedValues = selectedOptions
      ? selectedOptions.map((option) => option.value)
      : [];
    setSelectedOptions(selectedOptions || []);

    setInitialVisibleColumn(() => {
      const defaultColumns = allColumns.slice(0, 10).map((column) => column.id);

      if (selectedValues.length === 0) {
        console.log(
          'No columns selected. Showing default columns.',
          defaultColumns,
        );
        return [...defaultColumns];
      }

      const addedColumns = selectedValues.filter(
        (value) => !defaultColumns.includes(value),
      );

      const removedColumns = defaultColumns.filter(
        (value) => !selectedValues.includes(value),
      );

      const newVisibleColumns = [
        ...defaultColumns.filter((column) => !removedColumns.includes(column)),
        ...addedColumns,
      ];

      console.log('Filtered Visible Columns:', newVisibleColumns);
      return newVisibleColumns;
    });
  };
  const handleCellInputChange = (rowIndex, columnId, value) => {
    if (selectedVlaue) {
      console.log(selectedVlaue, 'Selected Value');
      data[rowIndex][columnId] = selectedVlaue?.label
        ? selectedVlaue?.label
        : value;
    } else if (value) {
      data[rowIndex][columnId] = value;
    }
  };

  const handleCellInlineChange = (rowIndex, columnId, value) => {
    data[rowIndex][columnId] = value;
  };

  const handleCellClick = (rowIndex, columnId, value) => {};

  const getSortingIcon = (isSorted, isSortedDesc) => {
    if (isSorted) {
      return isSortedDesc ? '🔽' : '🔼';
    } else {
      return '⬍';
    }
  };

  const handleOpenDropdown = () => {
    setIsDropdownOpen(true);
  };

  const handleCloseDropdown = () => {
    setIsDropdownOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (selectRef.current && !selectRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <Fragment>
      <Row className="mb-2">
        {isCustomPageSize && (
          <Col sm={2}>
            <select
              className="form-select pageSize mb-2"
              value={table.getState().pagination.pageSize}
              onChange={(e) => {
                table.setPageSize(Number(e.target.value));
              }}
            >
              {[10, 20, 30, 40, 50].map((pageSize) => (
                <option key={pageSize} value={pageSize}>
                  Show {pageSize}
                </option>
              ))}
            </select>
          </Col>
        )}

        {isGlobalFilter && (
          <DebouncedInput
            value={globalFilter ?? ''}
            onChange={(value) => setGlobalFilter(String(value))}
            className="form-control search-box me-2 mb-2 d-inline-block"
            placeholder={SearchPlaceholder}
          />
        )}

        {isAddButton && (
          <Col sm={12}>
            <div className="text-sm-end">
              <Button type="button" color="primary" onClick={handleUserClick}>
                <i className="mdi mdi-plus me-1"></i> {buttonName}
              </Button>
            </div>
          </Col>
        )}
        {showSelect && (
          <div ref={selectRef} className="d-flex justify-content-end">
            <Select
              isMulti
              options={options}
              onChange={handleChange}
              value={selectedOptions}
              placeholder="Select a column to display"
              isClearable
              styles={customStyles}
              menuIsOpen={isDropdownOpen}
              onMenuOpen={handleOpenDropdown}
              closeMenuOnSelect={false}
              onMenuClose={handleCloseDropdown}
            />
          </div>
        )}
      </Row>

      <div className={divClassName ? divClassName : 'table-responsive'}>
        <Table hover className={tableClass} bordered={isBordered}>
          <thead className={theadClass}>
            <tr>
              {getHeaderGroups().map((headerGroup) => {
                // Filter headers based on initialVisibleColumn
                const filteredHeaders = headerGroup.headers.filter((item) =>
                  initialVisibleColumn.includes(item.id),
                );
                // Ensure only the first 7 columns are shown

                return filteredHeaders.map((header, index) => (
                  <th
                    key={header.id}
                    colSpan={header.colSpan}
                    className={`${
                      header.column.columnDef.enableSorting
                        ? 'sorting sorting_desc'
                        : ''
                    }`}
                  >
                    {header.isPlaceholder ? null : (
                      <div
                        className={
                          header.column.getCanSort()
                            ? 'cursor-pointer select-none'
                            : ''
                        }
                        onClick={header.column.getToggleSortingHandler()}
                      >
                        {flexRender(
                          header.column.columnDef.header,
                          header.getContext(),
                        )}
                        <span>
                          {getSortingIcon(
                            header.column.getIsSorted(),
                            header.column.getIsSorted() === 'desc',
                          )}
                        </span>
                        {/* {{
              asc: "🔼",
              desc: "🔽",
            }[header.column.getIsSorted()] ?? null} */}
                      </div>
                    )}
                  </th>
                ));
              })}
              {showActionColumn && <th>Action</th>}
            </tr>

            <tr className="sticky-header">
              {getHeaderGroups().map((headerGroup) => {
                // Filter headers based on initialVisibleColumn
                const filteredHeaders = headerGroup.headers.filter((header) =>
                  initialVisibleColumn.includes(header.id),
                );

                return filteredHeaders.map((header) => (
                  <th key={header.id} colSpan={header.colSpan}>
                    {header.column.getCanFilter() ? (
                      (header.column.columnDef as CustomColumnDef<any>)
                        .filterComponent ? (
                        React.createElement(
                          (header.column.columnDef as CustomColumnDef<any>)
                            .filterComponent,
                          { column: header.column },
                        )
                      ) : (
                        <Filter column={header.column} />
                      )
                    ) : null}
                  </th>
                ));
              })}
              <th></th> {/* Empty cell for the Action filter (if not needed) */}
            </tr>
          </thead>
          <tbody>
            {getRowModel().rows.map((row, rowIndex) => (
              <tr key={row.id}>
                {row
                  .getVisibleCells()
                  .filter((cell) =>
                    initialVisibleColumn.includes(cell.column.id),
                  ) // Filter cells
                  .map((cell) => (
                    <td
                      key={cell.id}
                      suppressContentEditableWarning={true}
                      contentEditable={editable === rowIndex} // Editable if row is editable
                      onBlur={(e) => {
                        if (editable === rowIndex) {
                          handleCellInlineChange(
                            rowIndex,
                            cell.column.id,
                            e.target.innerText,
                          );
                        }
                      }}
                      onClick={() => {
                        if (editable !== rowIndex) {
                          handleCellClick(
                            rowIndex,
                            cell.column.id,
                            cell.getValue(),
                          );
                        }
                      }}
                    >
                      {editable === rowIndex
                        ? (cell.column?.columnDef as CustomColumnDef<any>)
                            ?.editComponent // Use the custom type
                          ? React.createElement(
                              // eslint-disable-next-line @typescript-eslint/no-non-null-asserted-optional-chain
                              (cell.column?.columnDef as CustomColumnDefs<any>)
                                ?.editComponent!,
                              {
                                value: cell.getValue(),
                                onChange: (newValue: any) => {
                                  handleCellInputChange(
                                    rowIndex,
                                    cell.column.id,
                                    newValue,
                                  );
                                  setTempRowData((prev) => ({
                                    ...prev,
                                    [cell.column.id]: newValue,
                                  }));
                                },
                              },
                            )
                          : flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext(),
                            )
                        : flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext(),
                          )}
                    </td>
                  ))}
                <td style={{ whiteSpace: 'nowrap', padding: 0 }}>
                  {showActionColumn && (
                    <div style={{ display: 'flex', gap: '8px' }}>
                      {editable === rowIndex ? (
                        <Save
                          onClick={() => {
                            setEditable(null);
                            onEdit(row.original);
                            onCellEdit(rowIndex, tempRowData);
                          }}
                        />
                      ) : (
                        <Edit
                          onClick={() => {
                            if (moveTONextPage) {
                              moveTONextOnEdit(row.original);
                              return;
                            }
                            setEditable(rowIndex);
                          }}
                        />
                      )}
                      <Delete
                        onClick={() => {
                          onDelete(row.original);
                        }}
                      />
                      {CustomIcon && (
                        <CustomIcon
                          onClick={() => {
                            customIconOnClick(row.original?.id);
                          }}
                        />
                      )}
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>

      {isPagination && (
        <Row>
          <Col sm={12} md={5}>
            <div className="dataTables_info">
              Showing {getState().pagination.pageSize} of {data.length} Results
            </div>
          </Col>
          <Col sm={12} md={7}>
            <div className={paginationWrapper}>
              <ul className={pagination}>
                <li
                  className={`paginate_button page-item previous ${
                    !getCanPreviousPage() ? 'disabled' : ''
                  }`}
                >
                  <Link to="#" className="page-link" onClick={previousPage}>
                    <i className="mdi mdi-chevron-left"></i>
                  </Link>
                </li>
                {getPageOptions().map((item, key) => (
                  <li
                    key={key}
                    className={`paginate_button page-item ${
                      getState().pagination.pageIndex === item ? 'active' : ''
                    }`}
                  >
                    <Link
                      to="#"
                      className="page-link"
                      onClick={() => setPageIndex(item)}
                    >
                      {item + 1}
                    </Link>
                  </li>
                ))}
                <li
                  className={`paginate_button page-item next ${
                    !getCanNextPage() ? 'disabled' : ''
                  }`}
                >
                  <Link to="#" className="page-link" onClick={nextPage}>
                    <i className="mdi mdi-chevron-right"></i>
                  </Link>
                </li>
              </ul>
            </div>
          </Col>
        </Row>
      )}
    </Fragment>
  );
}

export default TableContainer;
