import React, { useMemo, useState } from 'react';
import TableContainer from './table';
import Select from 'react-select';
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Form,
  FormGroup,
  Label,
  Input,
} from 'reactstrap';

interface SourceData {
  id: string;
  sourceName: string;
  sourceType: string;
  connectionString: string;
  filePath: string;
  fileType: string;
}

export default function SourceManagement() {
  const sourceTypeOptions = [
    { value: 'blob', label: 'Blob' },
    { value: 'API', label: 'API' },
  ];

  const fileTypeOptions = [
    { value: 'CSV/DSV', label: 'CSV/DSV' },
    { value: 'JSON', label: 'JSON' },
  ];

  const sourceOptions = [
    { value: 'DEAMS', label: 'DEAMS' },
    { value: 'GFEBS', label: 'GFEBS' },
    { value: 'EDA', label: 'EDA' },
    { value: 'CRM', label: 'CRM' },
    { value: 'SAP', label: 'SAP' },
    { value: 'NetSuite', label: 'NetSuite' },
    { value: 'Salesforce', label: 'Salesforce' },
    { value: 'Oracle', label: 'Oracle' },
  ];

  const [modal, setModal] = useState<boolean>(false);
  const [deleteModal, setDeleteModal] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [formState, setFormState] = useState<SourceData>({
    id: '',
    sourceName: '',
    sourceType: '',
    connectionString: '',
    filePath: '',
    fileType: '',
  });

  const [data, setData] = useState<SourceData[]>([
    {
      id: '1',
      sourceName: 'DEAMS',
      sourceType: 'blob',
      connectionString: 'DefaultEndpointsProtocol=https;Account',
      filePath: 'containerA/FundingXXX.csv',
      fileType: 'CSV/DSV',
    },
    {
      id: '2',
      sourceName: 'GFEBS',
      sourceType: 'blob',
      connectionString: 'DefaultEndpointsProtocol=https;Account',
      filePath: 'containerB/FundingXX.csv',
      fileType: 'CSV/DSV',
    },
  ]);

  const toggleModal = () => setModal(!modal);
  const toggleDeleteModal = () => setDeleteModal(!deleteModal);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormState({ ...formState, [name]: value });
  };

  const handleAddSource = () => {
    const newSource: SourceData = {
      ...formState,
      id: (data.length + 1).toString(),
    };
    setData([...data, newSource]);
    toggleModal();
    resetForm();
  };

  const handleEditSource = () => {
    const updatedData = data.map((item) =>
      item.id === formState.id ? { ...formState } : item,
    );
    setData(updatedData);
    toggleModal();
    resetForm();
  };

  const handleDeleteSource = () => {
    const updatedData = data.filter((item) => item.id !== formState.id);
    setData(updatedData);
    toggleDeleteModal();
    resetForm();
  };

  const handleEditClick = (source: SourceData) => {
    setFormState(source);
    setIsEditing(true);
    toggleModal();
  };

  const handleDeleteClick = (source: SourceData) => {
    setFormState(source);
    toggleDeleteModal();
  };

  const resetForm = () => {
    setFormState({
      id: '',
      sourceName: '',
      sourceType: '',
      connectionString: '',
      filePath: '',
      fileType: '',
    });
    setIsEditing(false);
  };

  const columns = useMemo(
    () => [
      { header: 'Source Id', accessorKey: 'id' },
      { header: 'Source Name', accessorKey: 'sourceName' },
      { header: 'Source Type', accessorKey: 'sourceType' },
      {
        header: 'Connection String/Key Vault',
        accessorKey: 'connectionString',
      },
      { header: 'File Path', accessorKey: 'filePath' },
      { header: 'File Type', accessorKey: 'fileType' },
    ],
    [],
  );

  return (
    <React.Fragment>
      <TableContainer
        columns={columns}
        data={data}
        isGlobalFilter={false}
        buttonName="Add Source Config"
        buttonClass="primary"
        SearchPlaceholder="Enter text to search"
        isAddButton={true}
        handleUserClick={toggleModal}
        moveTONextOnEdit={handleEditClick}
        moveTONextPage={true}
        onDelete={handleDeleteClick}
      />

      <Modal isOpen={modal} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>
          {isEditing ? 'Edit Source' : 'Add Source'}
        </ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
              <Label for="sourceName">Source</Label>
              <Select
                name="sourceName"
                options={sourceOptions}
                value={sourceOptions.find(
                  (option) => option.value === formState.sourceName,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    sourceName: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for="sourceType">Source Type</Label>
              <Select
                name="sourceType"
                options={sourceTypeOptions}
                value={sourceTypeOptions.find(
                  (option) => option.value === formState.sourceType,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    sourceType: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for="connectionString">Connection String/Key Vault</Label>
              <Input
                type="text"
                name="connectionString"
                id="connectionString"
                value={formState.connectionString}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="filePath">File Path</Label>
              <Input
                type="text"
                name="filePath"
                id="filePath"
                value={formState.filePath}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="fileType">File Type</Label>
              <Select
                name="fileType"
                options={fileTypeOptions}
                value={fileTypeOptions.find(
                  (option) => option.value === formState.fileType,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    fileType: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button
            color="primary"
            onClick={isEditing ? handleEditSource : handleAddSource}
          >
            {isEditing ? 'Update Source' : 'Add Source'}
          </Button>
          <Button color="secondary" onClick={toggleModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={deleteModal} toggle={toggleDeleteModal}>
        <ModalHeader toggle={toggleDeleteModal}>Delete Source</ModalHeader>
        <ModalBody>
          <p>
            Are you sure you want to delete the following source configuration?
          </p>
          <Form>
            <FormGroup>
              <Label for="sourceName">Source</Label>
              <Input
                type="text"
                name="sourceName"
                id="sourceName"
                value={formState.sourceName}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="sourceType">Source Type</Label>
              <Input
                type="text"
                name="sourceType"
                id="sourceType"
                value={formState.sourceType}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="connectionString">Connection String/Key Vault</Label>
              <Input
                type="text"
                name="connectionString"
                id="connectionString"
                value={formState.connectionString}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="filePath">File Path</Label>
              <Input
                type="text"
                name="filePath"
                id="filePath"
                value={formState.filePath}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="fileType">File Type</Label>
              <Input
                type="text"
                name="fileType"
                id="fileType"
                value={formState.fileType}
                readOnly
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="danger" onClick={handleDeleteSource}>
            Delete
          </Button>
          <Button color="secondary" onClick={toggleDeleteModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </React.Fragment>
  );
}
