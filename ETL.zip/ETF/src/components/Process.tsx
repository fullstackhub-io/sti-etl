import React, { useMemo, useState } from 'react';
import TableContainer from './table';
import Select from 'react-select';
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Form,
  FormGroup,
  Label,
  Input,
} from 'reactstrap';
interface Process {
  id: string;
  sourceId: string;
  sourceName: string;
  targetTable: string;
  LoadRules: string;
  activityFlag: string;
  order: number;
  lastUpdatedTime: string;
}
export default function Process() {
  const sourceOptions = [
    { value: 'SRC001', label: 'Source A' },
    { value: 'SRC002', label: 'Source B' },
  ];

  const activityOptions = [
    { value: 'Active', label: 'Active' },
    { value: 'Inactive', label: 'Inactive' },
  ];
  const [modal, setModal] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [formState, setFormState] = useState<Process>({
    id: '',
    sourceId: '',
    sourceName: '',
    targetTable: '',
    LoadRules: '',
    activityFlag: '',
    order: 0,
    lastUpdatedTime: '',
  });

  const [data, setData] = useState<Process[]>([
    {
      id: '1',
      sourceId: 'SRC001',
      sourceName: 'Source A',
      targetTable: 'TargetTable1',
      LoadRules: 'Rule1',
      activityFlag: 'Active',
      order: 1,
      lastUpdatedTime: '2024-10-07 10:00:00',
    },
    {
      id: '2',
      sourceId: 'SRC002',
      sourceName: 'Source B',
      targetTable: 'TargetTable2',
      LoadRules: 'Rule2',
      activityFlag: 'Inactive',
      order: 2,
      lastUpdatedTime: '2024-10-07 11:00:00',
    },
  ]);

  const toggleModal = () => setModal(!modal);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormState({ ...formState, [name]: value });
  };

  const handleAddProcess = () => {
    const newProcess: Process = {
      ...formState,
      id: (data.length + 1).toString(),
      lastUpdatedTime: new Date().toISOString().split('T')[0],
    };
    setData([...data, newProcess]);
    toggleModal();
    resetForm();
  };

  const handleEditProcess = () => {
    const updatedData = data.map((item) =>
      item.id === formState.id
        ? {
            ...formState,
            lastUpdatedTime: new Date().toISOString().split('T')[0], // Update lastUpdatedTime
          }
        : item,
    );
    setData(updatedData);
    toggleModal();
    resetForm();
  };

  const handleEditClick = (process: Process) => {
    setFormState(process);
    setIsEditing(true);
    toggleModal();
  };
  const [deleteModal, setDeleteModal] = useState(false);
  const handleDeleteClick = (mapping: Process) => {
    setFormState(mapping);
    toggleDeleteModal();
  };
  const handleDeleteProcess = () => {
    const updatedData = data.filter((item) => item.id !== formState.id);
    setData(updatedData);
    toggleDeleteModal();
    resetForm();
  };
  const resetForm = () => {
    setFormState({
      id: '',
      sourceId: '',
      sourceName: '',
      targetTable: '',
      LoadRules: '',
      activityFlag: '',
      order: 0,
      lastUpdatedTime: '',
    });
    setIsEditing(false);
  };

  const columns = useMemo(
    () => [
      {
        header: 'Process Id',
        accessorKey: 'id',
        enableColumnFilter: true,
        enableSorting: true,
      },
      {
        header: 'Source ID',
        accessorKey: 'sourceId',
        enableColumnFilter: true,
        enableSorting: true,
      },
      {
        header: 'Source',
        accessorKey: 'sourceName',
        enableColumnFilter: true,
        enableSorting: true,
        enableFiltering: true,
      },
      {
        header: 'Target Table',
        accessorKey: 'targetTable',
        enableColumnFilter: true,
        enableSorting: true,
      },
      {
        header: 'Load Rules',
        accessorKey: 'LoadRules',
        enableColumnFilter: true,
        enableSorting: true,
      },
      {
        header: 'Activity Flag',
        accessorKey: 'activityFlag',
        enableColumnFilter: true,
        enableSorting: true,
      },
      {
        header: 'Order',
        accessorKey: 'order',
        enableColumnFilter: true,
        enableSorting: true,
      },
      {
        header: 'Last Updated Time',
        accessorKey: 'lastUpdatedTime',
        enableColumnFilter: true,
        enableSorting: true,
      },
    ],
    [],
  );
  const toggleDeleteModal = () => setDeleteModal(!deleteModal);
  return (
    <React.Fragment>
      <TableContainer
        columns={columns}
        data={data}
        isGlobalFilter={false}
        buttonName="Add Process"
        buttonClass="primary"
        SearchPlaceholder="Enter Text to search"
        isAddButton={true}
        handleUserClick={toggleModal}
        moveTONextOnEdit={handleEditClick}
        moveTONextPage={true}
        onDelete={handleDeleteClick}
      />

      <Modal isOpen={modal} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>
          {isEditing ? 'Edit Process' : 'Add Process'}
        </ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
              <Label for="sourceId">Source ID</Label>
              <Select
                name="sourceId"
                options={sourceOptions}
                value={sourceOptions.find(
                  (option) => option.value === formState.sourceId,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    sourceId: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for="sourceName">Source Name</Label>
              <Input
                type="text"
                name="sourceName"
                id="sourceName"
                value={formState.sourceName}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="targetTable">Target Table</Label>
              <Input
                type="text"
                name="targetTable"
                id="targetTable"
                value={formState.targetTable}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="LoadRules">Load Rules</Label>
              <Input
                type="text"
                name="LoadRules"
                id="LoadRules"
                value={formState.LoadRules}
                onChange={handleInputChange}
              />
            </FormGroup>
            <FormGroup>
              <Label for="activityFlag">Activity Flag</Label>
              <Select
                name="activityFlag"
                options={activityOptions}
                value={activityOptions.find(
                  (option) => option.value === formState.activityFlag,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    activityFlag: selectedOption?.value || '',
                  })
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for="order">Order</Label>
              <Input
                type="number"
                name="order"
                id="order"
                value={formState.order}
                onChange={(e) =>
                  setFormState({
                    ...formState,
                    order: parseInt(e.target.value),
                  })
                }
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button
            color="primary"
            onClick={isEditing ? handleEditProcess : handleAddProcess}
          >
            {isEditing ? 'Update Process' : 'Add Process'}
          </Button>
          <Button color="secondary" onClick={toggleModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
      <Modal isOpen={deleteModal} toggle={toggleDeleteModal}>
        <ModalHeader toggle={toggleDeleteModal}>{'Delete Process'}</ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
              <Label for="sourceId">Source ID</Label>
              <Select
                name="sourceId"
                options={sourceOptions}
                value={sourceOptions.find(
                  (option) => option.value === formState.sourceId,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    sourceId: selectedOption?.value || '',
                  })
                }
                isDisabled={true}
              />
            </FormGroup>
            <FormGroup>
              <Label for="sourceName">Source Name</Label>
              <Input
                type="text"
                name="sourceName"
                id="sourceName"
                value={formState.sourceName}
                onChange={handleInputChange}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="targetTable">Target Table</Label>
              <Input
                type="text"
                name="targetTable"
                id="targetTable"
                value={formState.targetTable}
                onChange={handleInputChange}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="LoadRules">Load Rules</Label>
              <Input
                type="text"
                name="LoadRules"
                id="LoadRules"
                value={formState.LoadRules}
                onChange={handleInputChange}
                readOnly
              />
            </FormGroup>
            <FormGroup>
              <Label for="activityFlag">Activity Flag</Label>
              <Select
                name="activityFlag"
                options={activityOptions}
                value={activityOptions.find(
                  (option) => option.value === formState.activityFlag,
                )}
                onChange={(selectedOption) =>
                  setFormState({
                    ...formState,
                    activityFlag: selectedOption?.value || '',
                  })
                }
                isDisabled
              />
            </FormGroup>
            <FormGroup>
              <Label for="order">Order</Label>
              <Input
                type="number"
                name="order"
                id="order"
                value={formState.order}
                onChange={(e) =>
                  setFormState({
                    ...formState,
                    order: parseInt(e.target.value),
                  })
                }
                readOnly
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="danger" onClick={handleDeleteProcess}>
            Delete
          </Button>
          <Button color="secondary" onClick={toggleDeleteModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </React.Fragment>
  );
}
