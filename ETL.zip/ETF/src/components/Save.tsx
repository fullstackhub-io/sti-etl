import React from 'react';

export function Save({ onClick }) {
  return (
    <button style={styles.container} onClick={onClick} aria-label="Delete">
      <i className="bx bx-save" style={styles.icon}></i>
    </button>
  );
}

const styles = {
  container: {
    marginLeft: '5px',
    marginRight: '5px',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgb(142, 68, 173)',
    conlor: 'white',
    padding: '2px',
    paddingLeft: '8px',
    paddingRight: '8px',
    border: 'none',
    borderRadius: '5px',
  },
  icon: {
    color: 'white',
  },
};
