import React, { useState } from 'react';
import { Button, Modal } from 'reactstrap';

export function Delete({ onClick }) {
  const [modal, setModal] = useState();
  const [modal_center, setmodal_center] = useState(false);
  const tog_center = () => {
    setmodal_center(!modal_center);
  };
  return (
    <>
      <button style={styles.container} onClick={onClick} aria-label="Delete">
        <i className="fa fa-trash" style={styles.icon} aria-hidden="true"></i>
      </button>
    </>
  );
}

const styles = {
  container: {
    marginLeft: '5px',
    marginRight: '5px',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgb(192, 57, 43)',
    conlor: 'white',
    padding: '5px',
    paddingLeft: '8px',
    paddingRight: '8px',
    border: 'none',
    borderRadius: '5px',
  },
  icon: {
    color: 'white',
  },
};
